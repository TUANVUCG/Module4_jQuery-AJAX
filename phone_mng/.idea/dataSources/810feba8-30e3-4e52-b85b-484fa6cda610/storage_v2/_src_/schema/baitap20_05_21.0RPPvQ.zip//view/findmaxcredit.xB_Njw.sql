create view findmaxcredit as
select max(`baitap20_05_21`.`subject`.`Credit`) AS `CM`
from `baitap20_05_21`.`subject`;

